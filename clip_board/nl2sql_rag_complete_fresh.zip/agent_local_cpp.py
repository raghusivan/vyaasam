
import os, re, sqlite3
from typing import Tuple, List, Dict, Any
from llama_cpp import Llama

def load_llm(model_path: str, n_ctx: int = 4096, n_threads: int = 4, lora_path: str | None = None):
    return Llama(model_path=model_path, n_ctx=n_ctx, n_threads=n_threads, lora_path=lora_path, verbose=False)

def build_prompt(db_type: str, question: str, schema_chunks: List[str]) -> str:
    dialect = "SQLite" if db_type.lower() == "sqlite" else "PostgreSQL"
    schema_text = "\n\n".join(schema_chunks)
    guidelines = f"""
You are SQLCoder, an expert at writing {dialect} SQL.

RULES (very important):
- Use ONLY tables/columns that appear in the provided SCHEMA CONTRACT.
- If a needed column doesn't exist but can be computed, derive it with valid SQL (e.g., SUM(oi.quantity * p.price) for revenue).
- Do NOT invent table or column names. If the request cannot be answered with available schema, output exactly: CANNOT_ANSWER
- Return ONLY the SQL. No prose. End with a semicolon.
"""
    return f"""{guidelines}

SCHEMA CONTRACT:
{schema_text}

QUESTION:
{question}

SQL:
"""

def generate_sql(llm: Llama, prompt: str, max_tokens: int = 384) -> str:
    out = llm(prompt, max_tokens=max_tokens, stop=["\n\n", "#"], temperature=0.2)
    text = out["choices"][0]["text"].strip()
    text = re.sub(r"```(sql)?", "", text).strip()
    if not text.endswith(";") and text != "CANNOT_ANSWER":
        text += ";"
    return text

def run_sql_sqlite(db_path: str, sql: str) -> Tuple[List[str], List[List[Any]]]:
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute(sql)
    rows = cur.fetchall()
    cols = [d[0] for d in cur.description] if cur.description else []
    conn.close()
    return cols, rows

def run_sql_postgres(env: Dict[str, str], sql: str) -> Tuple[List[str], List[List[Any]]]:
    try:
        import psycopg
    except ImportError as e:
        raise RuntimeError(
            'Postgres support requires psycopg. Install with:\n'
            '  py -3.13 -m pip install --user "psycopg[binary]==3.2.9"'
        ) from e

    with psycopg.connect(
        host=env.get("PG_HOST", "localhost"),
        port=int(env.get("PG_PORT", "5432")),
        user=env.get("PG_USER", "postgres"),
        password=env.get("PG_PASSWORD", ""),
        dbname=env.get("PG_DATABASE", "postgres"),
    ) as conn:
        with conn.cursor() as cur:
            cur.execute(sql)
            rows = cur.fetchall()
            cols = [d[0] for d in cur.description] if cur.description else []
    return cols, rows
