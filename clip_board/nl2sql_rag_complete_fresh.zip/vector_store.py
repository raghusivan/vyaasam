
import os, re, math
from typing import List, Dict, Any
import chromadb

def _l2norm(v):
    n = math.sqrt(sum(x*x for x in v)) or 1.0
    return [x/n for x in v]

class BoWEmbedding:
    def __init__(self, dim: int = 768): self.dim = dim
    def __call__(self, input):
        if isinstance(input, str): input = [input]
        outs = []
        for text in input:
            vec = [0.0] * self.dim
            for tok in re.findall(r"[A-Za-z0-9_]+", str(text).lower()):
                vec[hash(tok) % self.dim] += 1.0
            outs.append(_l2norm(vec))
        return outs

class LlamaGGUFEmbedding:
    def __init__(self, model_path: str, n_ctx: int = 2048, n_threads: int = 4):
        from llama_cpp import Llama
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Embedding model not found: {model_path}")
        self.llm = Llama(model_path=model_path, n_ctx=n_ctx, n_threads=n_threads, embedding=True, verbose=False)
    def __call__(self, input):
        if isinstance(input, str): input = [input]
        outs = []
        for text in input:
            res = self.llm.create_embedding(text)
            emb = res["data"][0]["embedding"]
            outs.append(_l2norm(emb))
        return outs

class VectorStore:
    def __init__(self, persist_dir: str, collection: str):
        os.makedirs(persist_dir, exist_ok=True)
        self.client = chromadb.PersistentClient(path=persist_dir)
        self.name = collection

        backend = os.getenv("EMBEDDING_BACKEND", "bow").lower().strip()
        if backend == "llama":
            embed_path = os.getenv("EMBED_MODEL_PATH", "").strip()
            threads = int(os.getenv("EMBED_THREADS", "4"))
            ctx = int(os.getenv("EMBED_CTX", "2048"))
            self.embedder = LlamaGGUFEmbedding(embed_path, n_ctx=ctx, n_threads=threads)
        else:
            self.embedder = BoWEmbedding()

        try:
            self.col = self.client.get_collection(name=self.name)
        except Exception:
            self.col = self.client.get_or_create_collection(
                name=self.name,
                embedding_function=self.embedder,
                metadata={"hnsw:space": "cosine"},
            )

    def reset(self, name: str | None = None):
        name = name or self.name
        try:
            self.client.delete_collection(name=name)
        except Exception:
            pass
        self.col = self.client.get_or_create_collection(
            name=name,
            embedding_function=self.embedder,
            metadata={"hnsw:space": "cosine"},
        )

    def index_schema(self, docs: List[Dict[str, Any]]):
        if not docs: return
        ids, texts, metas = [], [], []
        for i, d in enumerate(docs):
            text = (
                f"Table: {d.get('table','')}\n"
                f"Columns: {', '.join(d.get('columns', []))}\n"
                f"Types: {d.get('types', {})}\n"
                f"PKs: {', '.join(d.get('primary_keys', [])) if d.get('primary_keys') else ''}\n"
                f"FKs: {d.get('foreign_keys', '')}\n"
                f"DDL: {d.get('create', '')}"
            )
            sample = d.get("sample", {})
            if sample and sample.get("rows"):
                text += f"\nSample: {sample['rows'][0]}"
            ids.append(f"tbl_{i}")
            texts.append(text)
            metas.append({"table": d.get("table", "")})
        self.col.upsert(ids=ids, documents=texts, metadatas=metas)

    def retrieve(self, question: str, k: int = 8) -> List[str]:
        try:
            if self.col.count() == 0: return []
        except Exception:
            return []
        res = self.col.query(query_texts=[question], n_results=k, include=["documents"])
        docs = res.get("documents", [[]])
        return docs[0] if docs else []
