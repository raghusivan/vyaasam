
import os, subprocess, sys, time, requests, threading
from dotenv import load_dotenv

def ensure_installed():
    needed = ["fastapi","uvicorn","requests","chromadb","llama_cpp","python_dotenv","tabulate"]
    missing = []
    for pkg in needed:
        try:
            __import__(pkg if pkg!="llama_cpp" else "llama_cpp")
        except Exception:
            missing.append(pkg)
    if missing:
        print("[i] Installing required packages to user site...")
        cmd = [sys.executable, "-m", "pip", "install", "--user", "-r", "requirements_no_admin.txt"]
        subprocess.check_call(cmd)

def run_db_setup():
    print("[i] Creating SQLite demo DB (if needed)...")
    subprocess.check_call([sys.executable, "db_setup_sqlite.py"])

def run_downloads():
    print("[i] Downloading models if configured...")
    subprocess.check_call([sys.executable, "download_model.py"])

def wait_for_health(url, timeout=180):
    start = time.time()
    while time.time()-start < timeout:
        try:
            r = requests.get(url, timeout=5)
            if r.ok:
                print("[+] Server is healthy."); return True
        except Exception:
            pass
        time.sleep(1)
    return False

def main():
    load_dotenv()
    host = os.getenv("HOST","127.0.0.1")
    port = os.getenv("PORT","8000")
    health_url = f"http://{host}:{port}/health"

    ensure_installed()
    if (os.getenv("DB_TYPE","sqlite").lower()=="sqlite") and (not os.path.exists(os.getenv("DB_PATH","demo.db"))):
        run_db_setup()
    run_downloads()

    print("[i] Starting backend server...")
    server = subprocess.Popen([sys.executable, "start_server.py"])
    try:
        ok = wait_for_health(health_url, timeout=300)
        if not ok:
            print("[!] Server did not become healthy in time. Check logs in the server window.")
            return
        print("[i] Launching desktop UI...")
        subprocess.call([sys.executable, "sql_promptUI.py"])
    finally:
        try:
            server.terminate()
        except Exception:
            pass

if __name__ == "__main__":
    main()
