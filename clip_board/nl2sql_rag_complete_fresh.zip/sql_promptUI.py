
import os, threading, requests, tkinter as tk
from tkinter import ttk, messagebox
from dotenv import load_dotenv

load_dotenv()
API_URL=os.getenv("API_URL","http://127.0.0.1:8000/nl2sql")

def run_query():
    q=txt_question.get("1.0", tk.END).strip()
    if not q: return
    btn_run.config(state=tk.DISABLED); status.set("Running...")
    threading.Thread(target=_call_api, args=(q,), daemon=True).start()

def _call_api(q):
    try:
        r=requests.post(API_URL, json={"question": q}, timeout=300)
        r.raise_for_status(); data=r.json()
        root.after(0, lambda: update_ui(data))
    except Exception as e:
        root.after(0, lambda: messagebox.showerror("Error", str(e)))
    finally:
        root.after(0, lambda: (btn_run.config(state=tk.NORMAL), status.set("Ready")))

def update_ui(data):
    txt_sql.config(state=tk.NORMAL); txt_sql.delete("1.0", tk.END); txt_sql.insert(tk.END, data.get("sql","")); txt_sql.config(state=tk.DISABLED)
    for row in tree.get_children(): tree.delete(row); tree["columns"]=()
    if data.get("error"):
        tree["columns"]=("Error",); tree.heading("Error", text="Error"); tree.column("Error", width=700)
        tree.insert("", tk.END, values=(data["error"],)); return
    res=data.get("result")
    if isinstance(res, dict) and "columns" in res and "rows" in res:
        headers=res["columns"]; tree["columns"]=headers
        for h in headers: tree.heading(h, text=h); tree.column(h, width=140)
        for r in res["rows"]: tree.insert("", tk.END, values=[str(x) for x in r])
        return
    tree["columns"]=("Output",); tree.heading("Output", text="Output"); tree.column("Output", width=700)
    tree.insert("", tk.END, values=(str(res),))

root=tk.Tk(); root.title("NL2SQL RAG (Local) — Fresh"); root.geometry("980x680")
frm=ttk.Frame(root, padding=10); frm.pack(fill="both", expand=True)
ttk.Label(frm, text="Enter your question:").pack(anchor="w")
txt_question=tk.Text(frm, height=3); txt_question.pack(fill="x")
btn_run=ttk.Button(frm, text="Run Query", command=run_query); btn_run.pack(pady=6)
ttk.Label(frm, text="Generated SQL:").pack(anchor="w")
txt_sql=tk.Text(frm, height=5, state=tk.DISABLED); txt_sql.pack(fill="x")
ttk.Label(frm, text="Results:").pack(anchor="w")
tree=ttk.Treeview(frm, show="headings"); tree.pack(fill="both", expand=True)
status=tk.StringVar(value="Ready"); ttk.Label(frm, textvariable=status).pack(anchor="w", pady=6)
root.mainloop()
