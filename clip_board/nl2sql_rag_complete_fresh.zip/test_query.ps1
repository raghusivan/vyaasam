
$body = @{ question = "top 3 products by units sold" } | ConvertTo-Json
Invoke-RestMethod -Uri "http://127.0.0.1:8000/nl2sql" -Method POST -Body $body -ContentType "application/json" | ConvertTo-Json -Depth 6
