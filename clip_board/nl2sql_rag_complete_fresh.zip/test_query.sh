
#!/usr/bin/env bash
set -e
curl -s -X POST "http://127.0.0.1:8000/nl2sql" \
  -H "Content-Type: application/json" \
  -d '{"question":"top 3 products by units sold"}' | jq .
