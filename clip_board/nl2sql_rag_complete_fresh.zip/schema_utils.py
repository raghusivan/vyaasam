
import os, sqlite3
from typing import List, Dict, Any, Tuple

def _sample_sqlite(conn, table: str, limit: int = 3):
    try:
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {table} LIMIT {limit}")
        rows = cur.fetchall()
        cols = [d[0] for d in cur.description]
        return cols, rows
    except Exception:
        return [], []

def extract_schema_sqlite(db_path: str) -> List[Dict[str, Any]]:
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
    tables = [r[0] for r in cur.fetchall()]
    docs = []
    for t in tables:
        cur.execute(f"PRAGMA table_info({t})")
        cols = cur.fetchall()
        cur.execute(f"PRAGMA foreign_key_list({t})")
        fks = cur.fetchall()
        col_desc = ", ".join([f"{c[1]} {c[2]}" for c in cols])
        fk_desc = "; ".join([f"FK {fk[3]} -> {fk[2]}({fk[4]})" for fk in fks]) or "None"
        pk_cols = [c[1] for c in cols if c[5] == 1]
        sample_cols, sample_rows = _sample_sqlite(conn, t, 3)
        docs.append({
            "table": t,
            "columns": [c[1] for c in cols],
            "types": {c[1]: c[2] for c in cols},
            "primary_keys": pk_cols,
            "foreign_keys": fk_desc,
            "create": f"CREATE TABLE {t} ({col_desc});",
            "sample": {"columns": sample_cols, "rows": sample_rows}
        })
    conn.close()
    return docs

def extract_schema_postgres(env: Dict[str, str]) -> List[Dict[str, Any]]:
    try:
        import psycopg  # v3
    except ImportError as e:
        raise RuntimeError(
            'Postgres support requires psycopg. Install with:\n'
            '  py -3.13 -m pip install --user "psycopg[binary]==3.2.9"'
        ) from e

    docs: List[Dict[str, Any]] = []
    with psycopg.connect(
        host=env.get("PG_HOST", "localhost"),
        port=int(env.get("PG_PORT", "5432")),
        user=env.get("PG_USER", "postgres"),
        password=env.get("PG_PASSWORD", ""),
        dbname=env.get("PG_DATABASE", "postgres"),
    ) as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema='public' AND table_type='BASE TABLE';
            """)
            tables = [r[0] for r in cur.fetchall()]

            for t in tables:
                cur.execute("""
                    SELECT column_name, data_type
                    FROM information_schema.columns
                    WHERE table_schema='public' AND table_name=%s
                    ORDER BY ordinal_position
                """, (t,))
                cols = cur.fetchall()

                cur.execute("""
                    SELECT
                        kcu.column_name, ccu.table_name, ccu.column_name
                    FROM information_schema.table_constraints tc
                    JOIN information_schema.key_column_usage kcu
                      ON tc.constraint_name=kcu.constraint_name
                    JOIN information_schema.constraint_column_usage ccu
                      ON ccu.constraint_name=tc.constraint_name
                    WHERE tc.constraint_type='FOREIGN KEY'
                      AND tc.table_schema='public'
                      AND tc.table_name=%s
                """, (t,))
                fks = cur.fetchall()
                fk_desc = "; ".join([f"FK {c[0]} -> {c[1]}({c[2]})" for c in fks]) or "None"

                sample_cols, sample_rows = [], []
                try:
                    cur.execute(f'SELECT * FROM "{t}" LIMIT 3')
                    sample_rows = cur.fetchall()
                    sample_cols = [d[0] for d in cur.description]
                except Exception:
                    pass

                docs.append({
                    "table": t,
                    "columns": [c[0] for c in cols],
                    "types": {c[0]: c[1] for c in cols},
                    "foreign_keys": fk_desc,
                    "create": f"CREATE TABLE {t} (...);",
                    "sample": {"columns": sample_cols, "rows": sample_rows}
                })
    return docs

def extract_schema(db_type: str, db_path: str, env: Dict[str, str]):
    if db_type.lower() == "sqlite":
        return extract_schema_sqlite(db_path)
    elif db_type.lower() == "postgres":
        return extract_schema_postgres(env)
    else:
        raise ValueError("Unsupported DB_TYPE")
