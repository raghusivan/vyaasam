
import sqlite3, os, random

DB_PATH = os.getenv("DB_PATH","demo.db")
if os.path.exists(DB_PATH): os.remove(DB_PATH)
conn=sqlite3.connect(DB_PATH); c=conn.cursor()

c.execute("CREATE TABLE customers (customer_id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL, country TEXT)")
c.execute("CREATE TABLE products (product_id INTEGER PRIMARY KEY AUTOINCREMENT, product_name TEXT NOT NULL, price REAL NOT NULL)")
c.execute("CREATE TABLE orders (order_id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, order_date TEXT NOT NULL, FOREIGN KEY(customer_id) REFERENCES customers(customer_id))")
c.execute("CREATE TABLE order_items (order_item_id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id INTEGER NOT NULL, quantity INTEGER NOT NULL, FOREIGN KEY(order_id) REFERENCES orders(order_id), FOREIGN KEY(product_id) REFERENCES products(product_id))")

countries=["AU","US","UK","DE","FR","IN"]
for i in range(1,201):
    c.execute("INSERT INTO customers (customer_name,country) VALUES (?,?)",(f"Customer_{i}", random.choice(countries)))

catalog=[ "Laptop","Phone","Tablet","Headphones","Monitor","Keyboard","Mouse","Printer","Camera","Smartwatch",
"Speaker","Charger","Router","External HDD","USB Drive","Microphone","Projector","Drone","VR Headset","Game Console",
"TV","Washing Machine","Refrigerator","Microwave","Oven","Air Conditioner","Heater","Fan","Vacuum Cleaner","Dishwasher",
"Coffee Maker","Toaster","Blender","Mixer","Juicer","Kettle","Hair Dryer","Shaver","Iron","Water Purifier",
"Fitness Tracker","Electric Scooter","Bicycle","Helmet","Backpack","Chair","Desk","Lamp","Sofa","Bed"]
for name in catalog:
    c.execute("INSERT INTO products (product_name, price) VALUES (?,?)",(name, round(random.uniform(20,2000),2)))

for _ in range(1000):
    cid=random.randint(1,200)
    c.execute("INSERT INTO orders (customer_id, order_date) VALUES (?, date('now','-{} day'))".format(random.randint(0,360)), (cid,))
    oid=c.lastrowid
    for __ in range(random.randint(1,5)):
        pid=random.randint(1,50); qty=random.randint(1,5)
        c.execute("INSERT INTO order_items (order_id, product_id, quantity) VALUES (?,?,?)",(oid,pid,qty))

conn.commit(); conn.close()
print(f"SQLite demo DB created at {DB_PATH}")
