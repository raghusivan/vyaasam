
import os, sys, time, requests
from dotenv import dotenv_values

def human(n):
    for unit in ['B','KB','MB','GB','TB']:
        if n < 1024: return f"{n:.1f}{unit}"
        n/=1024
    return f"{n:.1f}PB"

def download(url, dst):
    tmp = dst + ".part"
    headers = {}
    pos = 0
    if os.path.exists(tmp):
        pos = os.path.getsize(tmp)
        headers["Range"] = f"bytes={pos}-"
    with requests.get(url, stream=True, headers=headers, timeout=60) as r:
        r.raise_for_status()
        total = int(r.headers.get("Content-Length","0")) + pos
        mode = "ab" if pos else "wb"
        start = time.time(); got = pos
        with open(tmp, mode) as f:
            for chunk in r.iter_content(chunk_size=1024*1024):
                if chunk:
                    f.write(chunk); got += len(chunk)
                    dt = max(time.time()-start, 1e-6)
                    speed = human(got/dt) + "/s"
                    pct = (got/total*100) if total else 0.0
                    print(f"\r{human(got)} / {human(total)} ({pct:.1f}%) @ {speed}", end="")
    print()
    os.replace(tmp, dst)

def ensure_magic(path):
    try:
        with open(path, "rb") as f:
            magic = f.read(4)
        return magic == b"GGUF"
    except Exception:
        return False

def main():
    cfg = dotenv_values(".env")
    model_path = cfg.get("MODEL_PATH","models/sqlcoder.gguf")
    model_url  = cfg.get("MODEL_URL","")
    embed_backend = (cfg.get("EMBEDDING_BACKEND","bow") or "bow").lower()
    embed_path = cfg.get("EMBED_MODEL_PATH","models/embed-small.gguf")
    embed_url  = cfg.get("EMBED_MODEL_URL","")

    os.makedirs(os.path.dirname(model_path), exist_ok=True)

    if not os.path.exists(model_path):
        if model_url:
            print(f"[+] Downloading base model to {model_path}")
            download(model_url, model_path)
            if not ensure_magic(model_path):
                print("[!] Warning: downloaded file does not appear to be a GGUF (magic != GGUF). Check the URL.")
        else:
            print(f"[!] MODEL_PATH not found and MODEL_URL is empty in .env. Set MODEL_URL to a valid GGUF download.")

    if embed_backend == "llama":
        os.makedirs(os.path.dirname(embed_path), exist_ok=True)
        if not os.path.exists(embed_path):
            if embed_url:
                print(f"[+] Downloading embedding model to {embed_path}")
                download(embed_url, embed_path)
                if not ensure_magic(embed_path):
                    print("[!] Warning: embedding file not GGUF (magic != GGUF).")
            else:
                print(f"[!] EMBED_MODEL_PATH not found and EMBED_MODEL_URL empty. Set EMBED_MODEL_URL or switch EMBEDDING_BACKEND=bow.")

if __name__ == "__main__":
    main()
