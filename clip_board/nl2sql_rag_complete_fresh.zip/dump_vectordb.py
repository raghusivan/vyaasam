
import os, json
from dotenv import dotenv_values
import chromadb

cfg = dotenv_values(".env")
VEC_DIR = cfg.get("VECTOR_DB_DIR", "./vectordb")
COLL    = cfg.get("SCHEMA_COLLECTION", "db_schema")

client = chromadb.PersistentClient(path=VEC_DIR)

try:
    col = client.get_collection(name=COLL)
except Exception as e:
    raise SystemExit(f"Collection '{COLL}' not found in {VEC_DIR}: {e}")

total = col.count()
page  = 200
print(f"Collection: {COLL} | Items: {total}")

all_items = []
for offset in range(0, total, page):
    batch = col.get(
        limit=page,
        offset=offset,
        include=["documents", "metadatas"]
    )
    ids   = batch.get("ids", [])
    docs  = batch.get("documents", [])
    metas = batch.get("metadatas", [])
    for i in range(len(ids)):
        all_items.append({
            "id": ids[i],
            "document": docs[i] if i < len(docs) else None,
            "metadata": metas[i] if i < len(metas) else None,
        })
    print(f"Fetched {min(offset+page, total)}/{total}")

out_path = "vectordb_dump.json"
with open(out_path, "w", encoding="utf-8") as f:
    json.dump({"collection": COLL, "count": total, "items": all_items}, f, ensure_ascii=False, indent=2)

print(f"Wrote {len(all_items)} items → {out_path}")
