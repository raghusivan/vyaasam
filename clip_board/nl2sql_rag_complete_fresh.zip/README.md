
# NL2SQL RAG (Local) — Fresh Build

## Quick start
```bash
python -m pip install --user -r requirements_no_admin.txt
python db_setup_sqlite.py
python download_model.py
python start_server.py
python sql_promptUI.py
```
Or one command:
```bash
python start_all.py
```

Configure `.env` as needed.
