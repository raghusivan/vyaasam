
import os, json, time, sqlite3
from fastapi import FastAPI, Query
from pydantic import BaseModel
from dotenv import dotenv_values
from typing import List, Dict, Any
from schema_utils import extract_schema
from vector_store import VectorStore
from agent_local_cpp import load_llm, build_prompt, generate_sql, run_sql_sqlite, run_sql_postgres

cfg = dotenv_values(".env")
DB_TYPE   = cfg.get("DB_TYPE","sqlite")
DB_PATH   = cfg.get("DB_PATH","demo.db")
MODEL_PATH= cfg.get("MODEL_PATH","models/sqlcoder.gguf")
LORA_PATH = cfg.get("LORA_PATH","") or None
VEC_DIR   = cfg.get("VECTOR_DB_DIR","./vectordb")
COLL      = cfg.get("SCHEMA_COLLECTION","db_schema")
HOST      = cfg.get("HOST","127.0.0.1"); PORT=int(cfg.get("PORT","8000"))
HISTORY_FILE = cfg.get("HISTORY_FILE","query_history.json")
TOP_K_DEFAULT = int(cfg.get("TOP_K_DEFAULT","8"))
REWRITE_RETRIES = int(cfg.get("REWRITE_RETRIES","2"))
SAFE_MODE = (cfg.get("SAFE_MODE","true").lower() == "true")

app = FastAPI(title="NL2SQL RAG (Local)")

if DB_TYPE.lower()=="sqlite" and not os.path.exists(DB_PATH):
    import db_setup_sqlite

def index_schema():
    global schema_docs, vs
    schema_docs = extract_schema(DB_TYPE, DB_PATH, cfg)
    vs = VectorStore(VEC_DIR, COLL)
    vs.reset(COLL)
    vs.index_schema(schema_docs)

index_schema()

if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(f"MODEL_PATH not found: {MODEL_PATH}")
llm = load_llm(MODEL_PATH, n_ctx=4096, n_threads=4, lora_path=LORA_PATH)

class QueryBody(BaseModel):
    question: str
    top_k: int | None = None
    dry_run: bool = False

def _explain_ok(sql: str) -> tuple[bool, str | None]:
    try:
        if DB_TYPE.lower()=="sqlite":
            conn = sqlite3.connect(DB_PATH); cur = conn.cursor()
            cur.execute("EXPLAIN QUERY PLAN " + sql)
            _ = cur.fetchall()
            conn.close()
            return True, None
        else:
            import psycopg
            with psycopg.connect(
                host=cfg.get("PG_HOST","localhost"),
                port=int(cfg.get("PG_PORT","5432")),
                user=cfg.get("PG_USER","postgres"),
                password=cfg.get("PG_PASSWORD",""),
                dbname=cfg.get("PG_DATABASE","postgres"),
            ) as conn:
                with conn.cursor() as cur:
                    cur.execute("EXPLAIN " + sql)
                    _ = cur.fetchall()
            return True, None
    except Exception as e:
        return False, str(e)

def _execute_sql(sql: str):
    if SAFE_MODE:
        ok, err = _explain_ok(sql)
        if not ok:
            raise RuntimeError(f"EXPLAIN failed: {err}")
    if DB_TYPE.lower() == "sqlite":
        return run_sql_sqlite(DB_PATH, sql)
    else:
        return run_sql_postgres(cfg, sql)

def _append_history(entry: Dict[str, Any]):
    try:
        data = []
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        data.append(entry)
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

@app.get("/health")
def health(): return {"status":"ok","db":DB_TYPE}

@app.get("/schema")
def schema(): return schema_docs

@app.post("/reindex")
def reindex(): index_schema(); return {"status":"reindexed","tables":len(schema_docs)}

@app.get("/vectordb")
def vectordb_list(limit: int = Query(100, ge=1, le=1000), offset: int = Query(0, ge=0), include_embeddings: bool = False):
    include = ["documents","metadatas"]
    if include_embeddings: include.append("embeddings")
    try:
        total = vs.col.count()
        batch = vs.col.get(limit=limit, offset=offset, include=include)
        return {
            "collection": COLL,
            "total": total,
            "limit": limit,
            "offset": offset,
            "ids": batch.get("ids", []),
            "documents": batch.get("documents", []),
            "metadatas": batch.get("metadatas", []),
            "embeddings_included": include_embeddings
        }
    except Exception as e:
        return {"error": str(e)}

@app.get("/history")
def history(limit: int = Query(100, ge=1, le=1000), offset: int = Query(0, ge=0)):
    if not os.path.exists(HISTORY_FILE):
        return {"count": 0, "items": []}
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return {"count": len(data), "items": data[offset:offset+limit]}

@app.post("/nl2sql")
def nl2sql(q: QueryBody):
    text = q.question.strip()
    if text.lower() in ["schema", "db details", "tables", "columns", "show schema"]:
        return {"question": text, "sql": "", "result": schema_docs}

    top_k = q.top_k or TOP_K_DEFAULT
    retries = REWRITE_RETRIES

    ctx: List[str] = vs.retrieve(text, k=top_k) or ["No schema context found."]
    prompt = build_prompt(DB_TYPE, text, ctx)
    sql = generate_sql(llm, prompt)

    if q.dry_run:
        return {"question": text, "sql": sql, "result": {"columns": [], "rows": []}}

    try:
        cols, rows = _execute_sql(sql)
        _append_history({"ts": time.time(), "question": text, "sql": sql, "ok": True, "rows": len(rows)})
        return {"question": text, "sql": sql, "result": {"columns": cols, "rows": rows}}
    except Exception as e:
        last_err = str(e)

    for attempt in range(1, retries + 1):
        repair_prompt = f"""{prompt}

The previous SQL caused this {DB_TYPE} error:
{last_err}

Please correct the SQL strictly following the SCHEMA CONTRACT. Do not invent tables/columns. If impossible, output CANNOT_ANSWER.

SQL:
"""
        sql = generate_sql(llm, repair_prompt)
        try:
            cols, rows = _execute_sql(sql)
            _append_history({"ts": time.time(), "question": text, "sql": sql, "ok": True, "rows": len(rows), "repaired": attempt})
            return {"question": text, "sql": sql, "result": {"columns": cols, "rows": rows}, "repaired": attempt}
        except Exception as e2:
            last_err = str(e2)

    _append_history({"ts": time.time(), "question": text, "sql": sql, "ok": False, "error": last_err})
    return {"question": text, "sql": sql, "error": last_err, "repaired": False}

if __name__=="__main__":
    import uvicorn
    uvicorn.run("start_server:app", host=HOST, port=PORT, reload=False)
