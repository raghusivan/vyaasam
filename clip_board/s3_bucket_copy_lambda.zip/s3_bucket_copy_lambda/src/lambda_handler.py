"""
Lambda handler module for S3 bucket copy functionality.
Provides the AWS Lambda handler function that orchestrates the S3 bucket copy process.
"""

import os
import json
import logging
from typing import Dict, Any, Optional, Tuple

from src.config_handler import ConfigHandler
from src.s3_bucket_copy import S3BucketCopy

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def setup_logging(log_config: Dict[str, str]) -> None:
    """
    Configure logging based on configuration.
    
    Args:
        log_config: Logging configuration dictionary
    """
    log_level = getattr(logging, log_config.get('log_level', 'INFO'))
    log_format = log_config.get('log_format', '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Configure root logger
    logger.setLevel(log_level)
    
    # Remove existing handlers to avoid duplicates
    for handler in logger.handlers:
        logger.removeHandler(handler)
    
    # Create a new handler with the specified format
    handler = logging.StreamHandler()
    formatter = logging.Formatter(log_format)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    logger.info(f"Logging configured with level: {log_level}")

def process_event(event: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process the Lambda event and perform S3 bucket copy operations.
    
    Args:
        event: Lambda event dictionary
        config: Configuration dictionary
        
    Returns:
        Dictionary containing the results of the operation
    """
    logger.info(f"Processing event: {json.dumps(event)}")
    
    # Initialize S3 bucket copy handler
    s3_copy = S3BucketCopy(config, logger)
    
    # Check if the event specifies a specific file to copy
    if 'source_key' in event:
        source_key = event['source_key']
        target_key = event.get('target_key')  # Optional
        delete_after_copy = event.get('delete_after_copy', False)
        
        logger.info(f"Copying single object: {source_key}")
        success, duration = s3_copy.copy_single_object(
            source_key=source_key,
            target_key=target_key,
            delete_after_copy=delete_after_copy
        )
        
        result = {
            'success': success,
            'duration_seconds': duration,
            'source_key': source_key,
            'target_key': target_key or s3_copy.target_prefix + source_key[len(s3_copy.source_prefix):] 
                          if source_key.startswith(s3_copy.source_prefix) else source_key,
            'operation': 'single_copy'
        }
    else:
        # Perform batch copy operation
        delete_after_copy = event.get('delete_after_copy', False)
        
        logger.info("Performing batch copy operation")
        successful_copies, failed_copies, duration = s3_copy.copy_objects(
            delete_after_copy=delete_after_copy
        )
        
        result = {
            'success': failed_copies == 0,
            'duration_seconds': duration,
            'successful_copies': successful_copies,
            'failed_copies': failed_copies,
            'source_bucket': s3_copy.source_bucket,
            'source_prefix': s3_copy.source_prefix,
            'target_bucket': s3_copy.target_bucket,
            'target_prefix': s3_copy.target_prefix,
            'operation': 'batch_copy'
        }
    
    logger.info(f"Operation result: {json.dumps(result)}")
    return result

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler function for S3 bucket copy functionality.
    
    Args:
        event: Lambda event dictionary
        context: Lambda context object
        
    Returns:
        Dictionary containing the results of the operation
    """
    try:
        logger.info("S3 Bucket Copy Lambda function started")
        
        # Load configuration
        config_handler = ConfigHandler()
        config = config_handler.get_all_config()
        
        # Set up logging based on configuration
        setup_logging(config['logging'])
        
        # Override configuration with event parameters if provided
        if 'config_override' in event:
            override = event['config_override']
            
            if 'source_bucket' in override:
                config['aws']['source_bucket'] = override['source_bucket']
            
            if 'target_bucket' in override:
                config['aws']['target_bucket'] = override['target_bucket']
            
            if 'source_prefix' in override:
                config['paths']['source_prefix'] = override['source_prefix']
            
            if 'target_prefix' in override:
                config['paths']['target_prefix'] = override['target_prefix']
            
            logger.info(f"Configuration overridden with event parameters: {json.dumps(override)}")
        
        # Process the event
        result = process_event(event, config)
        
        return {
            'statusCode': 200,
            'body': result
        }
    
    except Exception as e:
        logger.error(f"Error in Lambda handler: {str(e)}", exc_info=True)
        
        return {
            'statusCode': 500,
            'body': {
                'error': str(e),
                'success': False
            }
        }
