"""
Configuration handler for S3 bucket copy Lambda function.
Reads and provides access to configuration parameters from config.ini file.
"""

import os
import configparser
import logging
from typing import Dict, Any, Optional

class ConfigHandler:
    """
    Handles configuration loading and access for the S3 bucket copy Lambda function.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the configuration handler.
        
        Args:
            config_path: Path to the config.ini file. If None, uses default path.
        """
        self.logger = logging.getLogger(__name__)
        
        # Default config path is in the same directory as the Lambda package
        if not config_path:
            # For Lambda, the config file would be in the same directory as the code
            lambda_task_root = os.environ.get('LAMBDA_TASK_ROOT', '')
            if lambda_task_root:
                config_path = os.path.join(lambda_task_root, 'config', 'config.ini')
            else:
                # For local development
                config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'config.ini')
        
        self.config_path = config_path
        self.config = configparser.ConfigParser()
        self.load_config()
    
    def load_config(self) -> None:
        """
        Load configuration from the config.ini file.
        
        Raises:
            FileNotFoundError: If the config file doesn't exist.
            configparser.Error: If there's an error parsing the config file.
        """
        try:
            self.logger.info(f"Loading configuration from {self.config_path}")
            if not os.path.exists(self.config_path):
                self.logger.error(f"Config file not found at {self.config_path}")
                raise FileNotFoundError(f"Config file not found at {self.config_path}")
            
            self.config.read(self.config_path)
            self.logger.info("Configuration loaded successfully")
        except configparser.Error as e:
            self.logger.error(f"Error parsing config file: {str(e)}")
            raise
    
    def get_aws_config(self) -> Dict[str, str]:
        """
        Get AWS configuration parameters.
        
        Returns:
            Dict containing AWS configuration parameters.
        """
        return {
            'region': self.config.get('aws', 'region'),
            'source_bucket': self.config.get('aws', 'source_bucket'),
            'target_bucket': self.config.get('aws', 'target_bucket')
        }
    
    def get_path_config(self) -> Dict[str, str]:
        """
        Get path configuration parameters.
        
        Returns:
            Dict containing path configuration parameters.
        """
        return {
            'source_prefix': self.config.get('paths', 'source_prefix'),
            'target_prefix': self.config.get('paths', 'target_prefix')
        }
    
    def get_logging_config(self) -> Dict[str, str]:
        """
        Get logging configuration parameters.
        
        Returns:
            Dict containing logging configuration parameters.
        """
        return {
            'log_level': self.config.get('logging', 'log_level'),
            'log_format': self.config.get('logging', 'log_format')
        }
    
    def get_lambda_config(self) -> Dict[str, Any]:
        """
        Get Lambda configuration parameters.
        
        Returns:
            Dict containing Lambda configuration parameters.
        """
        return {
            'timeout': self.config.getint('lambda', 'timeout'),
            'memory_size': self.config.getint('lambda', 'memory_size')
        }
    
    def get_all_config(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all configuration parameters.
        
        Returns:
            Dict containing all configuration parameters organized by section.
        """
        return {
            'aws': self.get_aws_config(),
            'paths': self.get_path_config(),
            'logging': self.get_logging_config(),
            'lambda': self.get_lambda_config()
        }
