"""
Logging utilities for S3 bucket copy Lambda function.
Provides enhanced logging functionality with timing and performance metrics.
"""

import os
import json
import time
import logging
from datetime import datetime
from functools import wraps
from typing import Dict, Any, Callable, Optional, TypeVar, cast

# Type variable for generic function type
F = TypeVar('F', bound=Callable[..., Any])

class LambdaLogFormatter(logging.Formatter):
    """
    Custom formatter for Lambda logs that outputs JSON format for better CloudWatch integration.
    """
    
    def format(self, record: logging.LogRecord) -> str:
        """
        Format the log record as JSON.
        
        Args:
            record: The log record to format
            
        Returns:
            JSON formatted log string
        """
        log_data = {
            'timestamp': datetime.utcfromtimestamp(record.created).isoformat() + 'Z',
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'function': record.funcName,
            'line': record.lineno
        }
        
        # Add exception info if available
        if record.exc_info:
            log_data['exception'] = self.formatException(record.exc_info)
        
        # Add extra fields if available
        if hasattr(record, 'extra'):
            log_data.update(record.extra)
        
        return json.dumps(log_data)

def setup_json_logging(log_level: str = 'INFO') -> None:
    """
    Set up JSON formatted logging for Lambda.
    
    Args:
        log_level: Logging level to use
    """
    level = getattr(logging, log_level)
    
    # Get the root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    
    # Remove existing handlers to avoid duplicates
    for handler in root_logger.handlers:
        root_logger.removeHandler(handler)
    
    # Create a new handler with JSON formatter
    handler = logging.StreamHandler()
    handler.setFormatter(LambdaLogFormatter())
    root_logger.addHandler(handler)
    
    root_logger.info("JSON logging configured", extra={'setup': 'complete'})

def timed_function(logger: Optional[logging.Logger] = None) -> Callable[[F], F]:
    """
    Decorator to time function execution and log the duration.
    
    Args:
        logger: Logger to use for logging. If None, uses the function's module logger.
        
    Returns:
        Decorated function
    """
    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Get the logger
            nonlocal logger
            if logger is None:
                logger = logging.getLogger(func.__module__)
            
            # Log function start
            func_name = func.__name__
            logger.info(f"Starting {func_name}", extra={'operation': func_name, 'status': 'start'})
            
            # Record start time
            start_time = time.time()
            
            try:
                # Execute the function
                result = func(*args, **kwargs)
                
                # Calculate duration
                duration = time.time() - start_time
                
                # Log function completion
                logger.info(
                    f"Completed {func_name} in {duration:.2f} seconds",
                    extra={
                        'operation': func_name,
                        'status': 'complete',
                        'duration_seconds': duration
                    }
                )
                
                return result
            except Exception as e:
                # Calculate duration
                duration = time.time() - start_time
                
                # Log function failure
                logger.error(
                    f"Failed {func_name} after {duration:.2f} seconds: {str(e)}",
                    extra={
                        'operation': func_name,
                        'status': 'failed',
                        'duration_seconds': duration,
                        'error': str(e)
                    },
                    exc_info=True
                )
                
                # Re-raise the exception
                raise
        
        return cast(F, wrapper)
    
    return decorator

def log_s3_metrics(logger: logging.Logger, operation: str, source_bucket: str, source_key: str,
                  target_bucket: Optional[str] = None, target_key: Optional[str] = None,
                  size_bytes: Optional[int] = None, duration_seconds: Optional[float] = None,
                  success: bool = True) -> None:
    """
    Log S3 operation metrics.
    
    Args:
        logger: Logger to use for logging
        operation: Operation name (e.g., 'copy', 'delete', 'list')
        source_bucket: Source S3 bucket name
        source_key: Source S3 key
        target_bucket: Target S3 bucket name (for copy operations)
        target_key: Target S3 key (for copy operations)
        size_bytes: Size of the object in bytes
        duration_seconds: Duration of the operation in seconds
        success: Whether the operation was successful
    """
    metrics = {
        'operation': operation,
        'source_bucket': source_bucket,
        'source_key': source_key,
        'success': success
    }
    
    if target_bucket:
        metrics['target_bucket'] = target_bucket
    
    if target_key:
        metrics['target_key'] = target_key
    
    if size_bytes is not None:
        metrics['size_bytes'] = size_bytes
        metrics['size_mb'] = size_bytes / (1024 * 1024)
    
    if duration_seconds is not None:
        metrics['duration_seconds'] = duration_seconds
        
        # Calculate transfer rate if both size and duration are available
        if size_bytes is not None and duration_seconds > 0:
            transfer_rate_mbps = (size_bytes / (1024 * 1024)) / duration_seconds
            metrics['transfer_rate_mbps'] = transfer_rate_mbps
    
    status = 'success' if success else 'failure'
    message = f"S3 {operation} {status}: {source_bucket}/{source_key}"
    
    if target_bucket and target_key:
        message += f" -> {target_bucket}/{target_key}"
    
    if size_bytes is not None and duration_seconds is not None:
        message += f" ({size_bytes / (1024 * 1024):.2f} MB in {duration_seconds:.2f}s)"
    
    log_method = logger.info if success else logger.error
    log_method(message, extra=metrics)
