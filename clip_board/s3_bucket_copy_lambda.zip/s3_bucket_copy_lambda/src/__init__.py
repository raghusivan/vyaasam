"""
S3 Bucket Copy Lambda package initialization.
"""

from src.config_handler import ConfigHandler
from src.s3_bucket_copy import S3BucketCopy
from src.lambda_handler import lambda_handler
from src.logging_utils import setup_json_logging, timed_function, log_s3_metrics

__version__ = '1.0.0'
__author__ = 'S3 Bucket Copy Lambda'
__all__ = ['ConfigHandler', 'S3BucketCopy', 'lambda_handler', 
           'setup_json_logging', 'timed_function', 'log_s3_metrics']
