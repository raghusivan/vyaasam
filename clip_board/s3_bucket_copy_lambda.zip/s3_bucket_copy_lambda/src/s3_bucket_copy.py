"""
S3 bucket copy functionality for Lambda function.
Provides functionality to copy files between S3 buckets with timing and logging.
"""

import os
import time
import logging
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any, Union

import boto3
from botocore.exceptions import ClientError

class S3BucketCopy:
    """
    Handles copying files between S3 buckets with detailed logging and timing.
    """
    
    def __init__(self, config: Dict[str, Any], logger: Optional[logging.Logger] = None):
        """
        Initialize the S3 bucket copy handler.
        
        Args:
            config: Configuration dictionary containing AWS and path settings
            logger: Logger instance for logging. If None, creates a new logger.
        """
        self.config = config
        
        # Set up logger
        self.logger = logger or logging.getLogger(__name__)
        
        # Initialize AWS clients
        self.region = config['aws']['region']
        self.source_bucket = config['aws']['source_bucket']
        self.target_bucket = config['aws']['target_bucket']
        self.source_prefix = config['paths']['source_prefix']
        self.target_prefix = config['paths']['target_prefix']
        
        # Initialize S3 client
        self.s3_client = boto3.client('s3', region_name=self.region)
        
        self.logger.info(f"Initialized S3BucketCopy with source bucket: {self.source_bucket}, "
                         f"target bucket: {self.target_bucket}")
    
    def list_objects(self, bucket: str, prefix: str) -> List[Dict[str, Any]]:
        """
        List objects in an S3 bucket with the given prefix.
        
        Args:
            bucket: Name of the S3 bucket
            prefix: Prefix to filter objects
            
        Returns:
            List of objects in the bucket with the given prefix
            
        Raises:
            ClientError: If there's an error listing objects
        """
        try:
            self.logger.info(f"Listing objects in bucket: {bucket} with prefix: {prefix}")
            start_time = datetime.now()
            
            # Handle pagination for large buckets
            paginator = self.s3_client.get_paginator('list_objects_v2')
            objects = []
            
            for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
                if 'Contents' in page:
                    objects.extend(page['Contents'])
            
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            self.logger.info(f"Listed {len(objects)} objects in {duration:.2f} seconds")
            
            return objects
        except ClientError as e:
            self.logger.error(f"Error listing objects in bucket {bucket}: {str(e)}")
            raise
    
    def copy_object(self, source_key: str, target_key: str) -> bool:
        """
        Copy a single object from source bucket to target bucket.
        
        Args:
            source_key: Key of the object in the source bucket
            target_key: Key to use in the target bucket
            
        Returns:
            True if copy was successful, False otherwise
            
        Raises:
            ClientError: If there's an error copying the object
        """
        try:
            start_time = datetime.now()
            self.logger.info(f"Copying object from {self.source_bucket}/{source_key} to {self.target_bucket}/{target_key}")
            
            # Perform the copy operation
            copy_source = {
                'Bucket': self.source_bucket,
                'Key': source_key
            }
            
            self.s3_client.copy_object(
                CopySource=copy_source,
                Bucket=self.target_bucket,
                Key=target_key
            )
            
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            # Get object size for reporting
            response = self.s3_client.head_object(Bucket=self.source_bucket, Key=source_key)
            size_mb = response.get('ContentLength', 0) / (1024 * 1024)
            
            self.logger.info(f"Successfully copied {size_mb:.2f} MB in {duration:.2f} seconds "
                            f"({size_mb/duration:.2f} MB/s if duration > 0)")
            return True
        except ClientError as e:
            self.logger.error(f"Error copying object {source_key}: {str(e)}")
            return False
    
    def delete_object(self, bucket: str, key: str) -> bool:
        """
        Delete an object from an S3 bucket.
        
        Args:
            bucket: Name of the S3 bucket
            key: Key of the object to delete
            
        Returns:
            True if deletion was successful, False otherwise
            
        Raises:
            ClientError: If there's an error deleting the object
        """
        try:
            self.logger.info(f"Deleting object {key} from bucket {bucket}")
            
            self.s3_client.delete_object(
                Bucket=bucket,
                Key=key
            )
            
            self.logger.info(f"Successfully deleted object {key} from bucket {bucket}")
            return True
        except ClientError as e:
            self.logger.error(f"Error deleting object {key}: {str(e)}")
            return False
    
    def copy_objects(self, delete_after_copy: bool = False) -> Tuple[int, int, float]:
        """
        Copy all objects from source bucket/prefix to target bucket/prefix.
        
        Args:
            delete_after_copy: Whether to delete objects from source after copying
            
        Returns:
            Tuple containing (successful_copies, failed_copies, total_duration_seconds)
        """
        self.logger.info(f"Starting copy operation from {self.source_bucket}/{self.source_prefix} "
                         f"to {self.target_bucket}/{self.target_prefix}")
        
        overall_start_time = datetime.now()
        
        # List objects in source bucket
        objects = self.list_objects(self.source_bucket, self.source_prefix)
        
        if not objects:
            self.logger.info("No objects found to copy")
            overall_end_time = datetime.now()
            overall_duration = (overall_end_time - overall_start_time).total_seconds()
            return 0, 0, overall_duration
        
        self.logger.info(f"Found {len(objects)} objects to copy")
        
        # Copy each object
        successful_copies = 0
        failed_copies = 0
        
        for obj in objects:
            source_key = obj['Key']
            
            # Calculate target key by replacing source prefix with target prefix
            if source_key.startswith(self.source_prefix):
                target_key = self.target_prefix + source_key[len(self.source_prefix):]
            else:
                target_key = source_key
            
            # Copy the object
            if self.copy_object(source_key, target_key):
                successful_copies += 1
                
                # Delete the source object if requested
                if delete_after_copy:
                    if self.delete_object(self.source_bucket, source_key):
                        self.logger.info(f"Deleted source object {source_key} after successful copy")
                    else:
                        self.logger.warning(f"Failed to delete source object {source_key} after copy")
            else:
                failed_copies += 1
        
        overall_end_time = datetime.now()
        overall_duration = (overall_end_time - overall_start_time).total_seconds()
        
        self.logger.info(f"Copy operation completed in {overall_duration:.2f} seconds")
        self.logger.info(f"Successfully copied {successful_copies} objects")
        
        if failed_copies > 0:
            self.logger.warning(f"Failed to copy {failed_copies} objects")
        
        return successful_copies, failed_copies, overall_duration
    
    def copy_single_object(self, source_key: str, target_key: Optional[str] = None, 
                          delete_after_copy: bool = False) -> Tuple[bool, float]:
        """
        Copy a single object from source bucket to target bucket.
        
        Args:
            source_key: Key of the object in the source bucket
            target_key: Key to use in the target bucket. If None, derives from source_key.
            delete_after_copy: Whether to delete the object from source after copying
            
        Returns:
            Tuple containing (success_status, duration_seconds)
        """
        start_time = datetime.now()
        
        if target_key is None:
            # Calculate target key by replacing source prefix with target prefix
            if source_key.startswith(self.source_prefix):
                target_key = self.target_prefix + source_key[len(self.source_prefix):]
            else:
                target_key = source_key
        
        success = self.copy_object(source_key, target_key)
        
        if success and delete_after_copy:
            if not self.delete_object(self.source_bucket, source_key):
                self.logger.warning(f"Failed to delete source object {source_key} after copy")
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        return success, duration
