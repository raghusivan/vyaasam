# S3 Bucket Copy Lambda

A professional AWS Lambda function for copying files between S3 buckets with extensive logging, timing metrics, and configuration flexibility.

## Overview

This project provides a reusable AWS Lambda function that efficiently copies files between S3 buckets. It features:

- Configuration-driven parameters via config.ini
- Comprehensive logging with performance metrics
- Detailed timing of all operations
- Support for both batch and single file operations
- Optional source file deletion after successful copy
- JSON-formatted structured logging for CloudWatch integration
- Flexible configuration overrides via Lambda event parameters

## Project Structure

```
s3_bucket_copy_lambda/
├── config/
│   └── config.ini           # Configuration file
├── src/
│   ├── config_handler.py    # Configuration loading and management
│   ├── lambda_handler.py    # AWS Lambda entry point
│   ├── logging_utils.py     # Enhanced logging utilities
│   └── s3_bucket_copy.py    # Core S3 bucket copy functionality
├── tests/                   # Unit and integration tests
├── README.md                # Project documentation
└── requirements.txt         # Python dependencies
```

## Configuration

The Lambda function is configured via the `config.ini` file with the following sections:

### AWS Configuration

```ini
[aws]
region = us-east-1
source_bucket = source-bucket-name
target_bucket = target-bucket-name
```

### Path Configuration

```ini
[paths]
source_prefix = source/
target_prefix = target/
```

### Logging Configuration

```ini
[logging]
log_level = INFO
log_format = %(asctime)s - %(name)s - %(levelname)s - %(message)s
```

### Lambda Configuration

```ini
[lambda]
timeout = 900
memory_size = 1024
```

## Usage

### Deployment

1. Clone the repository
2. Update the `config.ini` file with your AWS bucket information
3. Install dependencies: `pip install -r requirements.txt`
4. Package the Lambda function:
   ```bash
   zip -r s3_bucket_copy_lambda.zip src/ config/ requirements.txt
   ```
5. Deploy to AWS Lambda using the AWS CLI or Console

### Lambda Event Examples

#### Batch Copy Operation

Copy all files from source prefix to target prefix:

```json
{
  "delete_after_copy": false
}
```

#### Single File Copy Operation

Copy a specific file:

```json
{
  "source_key": "source/path/to/file.txt",
  "target_key": "target/path/to/file.txt",
  "delete_after_copy": false
}
```

#### Configuration Override

Override configuration parameters in the event:

```json
{
  "config_override": {
    "source_bucket": "different-source-bucket",
    "target_bucket": "different-target-bucket",
    "source_prefix": "different/source/path/",
    "target_prefix": "different/target/path/"
  },
  "delete_after_copy": true
}
```

## Lambda Response

The Lambda function returns a JSON response with detailed information about the operation:

### Batch Copy Response

```json
{
  "statusCode": 200,
  "body": {
    "success": true,
    "duration_seconds": 12.34,
    "successful_copies": 10,
    "failed_copies": 0,
    "source_bucket": "source-bucket-name",
    "source_prefix": "source/",
    "target_bucket": "target-bucket-name",
    "target_prefix": "target/",
    "operation": "batch_copy"
  }
}
```

### Single File Copy Response

```json
{
  "statusCode": 200,
  "body": {
    "success": true,
    "duration_seconds": 2.34,
    "source_key": "source/path/to/file.txt",
    "target_key": "target/path/to/file.txt",
    "operation": "single_copy"
  }
}
```

## Logging

The Lambda function uses structured JSON logging for better integration with CloudWatch Logs. Each log entry includes:

- Timestamp
- Log level
- Logger name
- Message
- Function name and line number
- Operation-specific metrics (duration, file size, transfer rate)

Example log entry:

```json
{
  "timestamp": "2025-03-25T00:10:15.123Z",
  "level": "INFO",
  "logger": "s3_bucket_copy",
  "message": "S3 copy success: source-bucket/source/file.txt -> target-bucket/target/file.txt (5.25 MB in 1.23s)",
  "function": "copy_object",
  "line": 123,
  "operation": "copy",
  "source_bucket": "source-bucket",
  "source_key": "source/file.txt",
  "target_bucket": "target-bucket",
  "target_key": "target/file.txt",
  "size_bytes": 5505024,
  "size_mb": 5.25,
  "duration_seconds": 1.23,
  "transfer_rate_mbps": 4.27,
  "success": true
}
```

## Performance Metrics

The Lambda function tracks and reports detailed performance metrics:

- Total operation duration
- Per-file copy duration
- File sizes
- Transfer rates (MB/s)
- Success/failure counts

## Error Handling

The Lambda function includes comprehensive error handling:

- Detailed error logging with stack traces
- Graceful failure handling for individual files in batch operations
- Clear error reporting in Lambda responses

## Future Enhancements

Planned future enhancements include:

- Support for multi-part uploads for large files
- Integration with SNS for notification of operation completion
- Support for file filtering based on patterns or metadata
- Parallel processing for improved performance
- CloudFormation template for easy deployment

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
