"""
Main entry point for the S3 bucket copy Lambda function.
This file is required for AWS Lambda to properly identify the handler function.
"""

from src.lambda_handler import lambda_handler

# This allows AWS Lambda to find the handler function
# Usage: s3_bucket_copy_lambda.main.handler
def handler(event, context):
    """
    Main handler function for AWS Lambda.
    
    Args:
        event: Lambda event dictionary
        context: Lambda context object
        
    Returns:
        Dictionary containing the results of the operation
    """
    return lambda_handler(event, context)
